# -*- coding: utf-8 -*-
"""
Created on Thu Sep 12 10:21:02 2024

@author: Karol Diaz
"""
import numpy as np
import matplotlib.pyplot as plt
from scipy.io import wavfile
from sklearn.decomposition import FastICA
from IPython.display import Audio, display

# Descripción del Sistema
print("Descripción del Sistema:")
print("Las fuentes de sonido (personas) están ubicadas en diferentes posiciones en la sala.")
print("Los micrófonos están colocados en posiciones fijas a una distancia conocida de las fuentes.")
print("La orientación de los micrófonos es tal que captura una mezcla de sonidos provenientes de las personas.")
print("Las distancias y orientaciones específicas se deben conocer y documentar en el diseño experimental.")
print("")

# Cargar el archivo de audio
fs, mezcla = wavfile.read('combiancion1.wav')

# Configuración del sistema de adquisición
print(f"Frecuencia de muestreo: {fs} Hz")
print(f"Duración del audio: {len(mezcla)/fs:.2f} segundos")

# Si el archivo tiene múltiples canales (ejemplo estéreo), conviértelo a mono
if len(mezcla.shape) == 2:
    mezcla = mezcla.mean(axis=1)

# Normalizar la señal
mezcla = mezcla / np.max(np.abs(mezcla))

# Niveles de cuantificación
n_bits = 16  # Suponiendo un archivo WAV con 16 bits de cuantificación
max_amplitude = 2 ** (n_bits - 1) - 1
print(f"Niveles de cuantificación: {max_amplitude} niveles")

# Número de componentes a separar (3 personas)
n_componentes = 3

# Aplicar FastICA para separar las fuentes
ica = FastICA(n_components=n_componentes, random_state=0)
mezcla_reshaped = mezcla.reshape(-1, 1)
componentes_separados = ica.fit_transform(np.column_stack([mezcla_reshaped]*n_componentes))

# Cálculo del SNR de la señal original
def calcular_snr(signal, noise):
    signal_power = np.mean(signal ** 2)
    noise_power = np.mean(noise ** 2)
    return 10 * np.log10(signal_power / noise_power)

# Suponiendo ruido como la señal original menos la señal reconstruida
ruido_estimado = mezcla - np.mean(componentes_separados, axis=1)
snr_original = calcular_snr(mezcla, ruido_estimado)
print(f"SNR del audio original: {snr_original:.2f} dB")
print("")

# Reproducción del audio original
print("Reproduciendo el audio original...")
display(Audio(mezcla, rate=fs))

# Reproducción de las señales separadas (selección de la voz de la persona)
for i in range(n_componentes):
    print(f"Reproduciendo la voz de la Persona {i+1} separada...")
    display(Audio(componentes_separados[:, i], rate=fs))

# Dar opción al usuario para seleccionar la voz
persona_elegida = int(input("¿Cuál voz deseas escuchar? (1, 2 o 3): "))
while persona_elegida not in [1, 2, 3]:
    persona_elegida = int(input("Entrada inválida. Por favor selecciona 1, 2 o 3: "))

print(f"Reproduciendo la voz de la Persona {persona_elegida}...")
display(Audio(componentes_separados[:, persona_elegida - 1], rate=fs))

# Análisis temporal
plt.figure(figsize=(12, 6))
plt.plot(np.linspace(0, len(mezcla) / fs, num=len(mezcla)), mezcla)
plt.title("Señal en el dominio del tiempo (Audio completo)")
plt.xlabel("Tiempo [s]")
plt.ylabel("Amplitud")
plt.grid(True)
plt.show()

# Transformada rápida de Fourier (FFT) para el análisis espectral
fft_mezcla = np.fft.fft(mezcla)
frecuencias = np.fft.fftfreq(len(fft_mezcla), 1/fs)

# Gráfica en el dominio de la frecuencia (frecuencias positivas) con escala logarítmica
plt.figure(figsize=(12, 6))
plt.plot(frecuencias[:len(frecuencias)//2], 20 * np.log10(np.abs(fft_mezcla[:len(frecuencias)//2]) + 1e-10))
plt.title("Espectro de frecuencias (Audio completo)")
plt.xlabel("Frecuencia [Hz]")
plt.ylabel("Magnitud [dB]")
plt.grid(True)
plt.show()

# Gráficas de las voces separadas en el dominio del tiempo
for i in range(n_componentes):
    plt.figure(figsize=(12, 6))
    plt.plot(np.linspace(0, len(componentes_separados[:, i]) / fs, num=len(componentes_separados[:, i])), componentes_separados[:, i])
    plt.title(f"Señal en el dominio del tiempo (Persona {i+1})")
    plt.xlabel("Tiempo [s]")
    plt.ylabel("Amplitud")
    plt.grid(True)
    plt.show()

# Análisis espectral de las voces separadas con escala logarítmica
for i in range(n_componentes):
    fft_persona = np.fft.fft(componentes_separados[:, i])
    plt.figure(figsize=(12, 6))
    plt.plot(frecuencias[:len(frecuencias)//2], 20 * np.log10(np.abs(fft_persona[:len(frecuencias)//2]) + 1e-10))
    plt.title(f"Espectro de frecuencias (Persona {i+1})")
    plt.xlabel("Frecuencia [Hz]")
    plt.ylabel("Magnitud [dB]")
    plt.grid(True)
    plt.show()

# Cálculo y discusión del SNR para cada componente
print("Cálculo del SNR para cada persona:")
for i in range(n_componentes):
    snr = calcular_snr(mezcla, componentes_separados[:, i])
    print(f"SNR para la Persona {i+1}: {snr:.2f} dB")

# Discusión de los resultados
print("\nDiscusión de los Resultados:")
print("El análisis en el dominio del tiempo muestra cómo varía la amplitud de la señal a lo largo del tiempo.")
print("El análisis en el dominio de la frecuencia revela la distribución de la energía en diferentes frecuencias.")
print("El uso de la escala logarítmica (dB) para la magnitud ayuda a visualizar mejor las diferencias en las frecuencias bajas.")
print("La separación de fuentes mediante ICA ha permitido aislar las voces de las personas. La calidad de esta separación se puede evaluar mediante el SNR.")
print("Un SNR más alto indica una mejor calidad de separación, mientras que un SNR más bajo sugiere que la señal separada contiene más ruido.")
print("Comparando el SNR del audio original con el de las señales separadas, se puede determinar cuán efectivamente se han aislado las fuentes.")
